// ==========================================================
// Program 1:  Implement a Dice class          File: main.cpp
// Author: Sam Lee
// ==========================================================

#include "dice.hpp"

int main (void){
    banner();
    unit1();
    bye();
}
