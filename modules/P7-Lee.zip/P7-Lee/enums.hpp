#include "tools.hpp"
#pragma once

enum GameEnum { BEGUN, DONE, QUIT };
