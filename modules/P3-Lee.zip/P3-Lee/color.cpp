// ===============================================================
// Class functions for color.hpp                   file: color.hpp
// ===============================================================

#include "color.hpp"

const char* Color::colorNames[6] = {"White", "Orange", "Yellow", "Green", "Blue", "Error"};

